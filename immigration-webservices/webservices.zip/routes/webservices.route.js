var express = require('express')

var router = express.Router()

// Getting the User Controller that we just created

var WebServiceController = require('../controllers/webservices.controller');

// Map each API to the Controller FUnctions

router.post('/getSelectedEmployeeList/', WebServiceController.getSelectedEmployeeList);

router.get('/getFliteredEmployeeList/:filtered_value', WebServiceController.getFliteredEmployeeList);

router.get('/login/:username/:password', WebServiceController.login);
// Export the Router
module.exports = router;